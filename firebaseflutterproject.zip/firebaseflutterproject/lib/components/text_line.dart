import 'components_list.dart';

Widget textLine({
  required String title,
  Color? color,
  required double fontSize,
  bool isBold = false,
  int? lines = 1,
  TextAlign? textAlign = TextAlign.center
}) {
  title = translate(title);
  return Text(
    title,
    maxLines: lines!,
    overflow: TextOverflow.ellipsis,
    textAlign: TextAlign.center,
    style: TextStyle(
      color: color ?? AppColors.textColor,
      fontSize: SizeConfig.safeBlockVertical = fontSize,
      fontWeight: isBold == true ? FontWeight.bold : FontWeight.normal,
    ),
  );
}

String translate(String word) {
  return word
      .replaceAll('_', ' ')
      .split(' ')
      .map((word) => capitalize(word))
      .join(' ');
}

String capitalize(String word) {
  if (word.isEmpty) return word;
  return word[0].toUpperCase() + word.substring(1);
}

Widget rowTextLine({
  required String title,
  required double textWidth,
  required double fontSize,
  Color? color,
  bool isBold = false,
  int? lines = 1,
}) {
  title = translate(title);
  return SizedBox(
    width: SizeConfig.blockSizeHorizontal = textWidth,
    child: Text(
      title,
      maxLines: lines!,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        color: color ?? AppColors.textColor,
        fontSize: SizeConfig.safeBlockVertical = fontSize,
        fontWeight: isBold == true ? FontWeight.bold : FontWeight.normal,
      ),
    ),
  );
}
