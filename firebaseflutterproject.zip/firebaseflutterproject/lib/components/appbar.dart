import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'components_list.dart'
    show
        AppBar,
        AppColors,
        Colors,
        Get,
        Icon,
        Icons,
        Image,
        InkWell,
        MainAxisAlignment,
        Row,
        VoidCallback,
        textLine,
        translate;

dynamic appMain() {
  return AppBar(
    backgroundColor: AppColors.white,
    surfaceTintColor: AppColors.white,
    title: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          "assets/icon/logo_task.png",
          height: 80,
          width: 80,
        ),
      ],
    ),
  );
}

dynamic appBarLeading(
  String name,
) {
  return AppBar(
    toolbarHeight: 40,
    backgroundColor: Colors.white,
    surfaceTintColor: Colors.white,
    centerTitle: true,
    leading: InkWell(
        onTap: () => Get.offAllNamed('mainPage'),
        child: const Icon(
          Icons.arrow_back,
          color: Colors.black,
        )),
    title: textLine(
        title: translate(name),
        fontSize: 17,
        isBold: true,
        color: AppColors.black),
  );
}

dynamic appBarBack(String name, VoidCallback onTap) {
  return AppBar(
    toolbarHeight: 40,
    backgroundColor: Colors.white,
    surfaceTintColor: Colors.white,
    centerTitle: true,
    leading: InkWell(
        onTap: () => Get.offAllNamed('mainPage'),
        child: const Icon(
          Icons.arrow_back,
          color: Colors.white,
        )),
    title: textLine(
        title: translate(name),
        fontSize: 17,
        isBold: true,
        color: AppColors.black),
  );
}
