import 'package:firebaseflutterproject/screens/search/search_screen.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:get/get_navigation/src/routes/transitions_type.dart';

import 'view_list.dart';

class AppRoutes {
  static final routes = [
    GetPage(
        name: '/home',
        page: () => const HomeScreen(),
        binding: MyBindings(),
        transition: Transition.rightToLeft),
    GetPage(
        name: '/signup',
        page: () => const SignupScreen(),
        binding: MyBindings(),
        transition: Transition.rightToLeft),
    GetPage(
        name: '/login',
        page: () => const LoginScreen(),
        binding: MyBindings(),
        transition: Transition.rightToLeft),
    GetPage(
        name: '/mainPage',
        page: () => const BottomNavBar(),
        binding: MyBindings(),
        transition: Transition.rightToLeft),
    GetPage(
        name: '/search',
        page: () => const SearchScreen(),
        binding: MyBindings(),
        transition: Transition.rightToLeft),
  ];
}
