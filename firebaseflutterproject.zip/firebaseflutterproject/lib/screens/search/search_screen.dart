import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../view_list.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final KeywordController controller = Get.put(KeywordController());
    final HomeController controller2 = Get.put(HomeController());
    List<Map<String, dynamic>> staticImageData = [
      {
        'urls': {
          'regular':
              'https://images.unsplash.com/photo-1639024363104-6d2ca539d52b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwzNjUyOXwwfDF8c2VhcmNofDkxfHxjaXJjdWl0fGVufDB8MHx8fDE2NDY4ODcyMjA&ixlib=rb-1.2.1&q=80&w=1080',
        }
      },
      {
        'urls': {
          'regular':
              'https://images.unsplash.com/photo-1652387311162-b8b1117452ae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwzNjUyOXwwfDF8c2VhcmNofDJ8fHxjYXR8ZW58MHx8fDE2NDY4ODc0Mzg&ixlib=rb-1.2.1&q=80&w=1080',
        }
      },
      {
        'urls': {
          'regular':
              'https://images.unsplash.com/photo-1622172845967-19e9d4d43a16?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwzNjUyOXwwfDF8c2VhcmNofDgxfHxjYXR8ZW58MHx8fDE2NDY4ODc2MTE&ixlib=rb-1.2.1&q=80&w=1080',
        }
      },
    ];

    var search = TextEditingController();
    bool test = false;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Search'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: search,
                cursorColor: AppColors.white,
                decoration: InputDecoration(
                  hintText: 'Search here ..',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(23),
                  ),
                ),
              ),
            ),
            buildRoundButton(
                width: 200,
                height: 50,
                radius: 20,
                title: "search",
                onPressed: () {
                  controller2.searchImage(searchKeyword: search.text);
                  controller.addKeyword(search.text, DateTime.now().toString());
                }),
            heightSpaceBox(size: 50),
            Obx(() {
              if (controller.isLoading.value) {
                return const SizedBox();
              }

              return SizedBox(
                height: 50.0 * controller.keywords.length,
                child: ListView.builder(
                  itemCount: controller.keywords.length,
                  itemBuilder: (context, index) {
                    var keyword = controller.keywords[index];
                    return ListTile(
                      title: Text(keyword['keyword']),
                      trailing: InkWell(
                        onTap: () => controller.deleteKeyword(keyword['id']),
                        child: const Icon(Icons.close),
                      ),
                    );
                  },
                ),
              );
            }),
            Obx(() => controller2.show.isTrue
                ? const SizedBox()
                : SizedBox(
                    width: double.infinity,
                    child: CarouselSlider(
                      options: CarouselOptions(
                        viewportFraction: 100,
                        initialPage: 0,
                        onPageChanged: (index, reason) {
                          controller2.searchImage(searchKeyword: search.text);
                        },
                        enableInfiniteScroll: true,
                        reverse: false,
                        autoPlay: true,
                        autoPlayInterval: const Duration(seconds: 10),
                        autoPlayAnimationDuration:
                            const Duration(milliseconds: 600),
                        autoPlayCurve: Curves.fastOutSlowIn,
                        enlargeCenterPage: true,
                        enlargeFactor: 0.3,
                        scrollDirection: Axis.horizontal,
                      ),
                      items: staticImageData.map<Widget>((item) {
                        var imageUrl = item['urls']['regular'];
                        return Builder(
                          builder: (BuildContext context) => Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(0),
                              image: DecorationImage(
                                image: NetworkImage(controller2.imageUrl.value),
                                fit: BoxFit
                                    .fitHeight, // Add BoxFit to ensure proper image scaling
                              ),
                              color: AppColors.white,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  )),
          ],
        ),
      ),
    );
  }
}
