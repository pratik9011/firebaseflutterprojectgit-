import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../view_list.dart'
    show
        AppColors,
        BorderRadius,
        BorderSide,
        BuildContext,
        Center,
        Column,
        Container,
        CrossAxisAlignment,
        EdgeInsets,
        FontWeight,
        Icon,
        Image,
        LoginController,
        MainAxisAlignment,
        MediaQuery,
        RoundedRectangleBorder,
        Row,
        SingleChildScrollView,
        SizeConfig,
        SizedBox,
        StatelessWidget,
        Text,
        TextInputAction,
        TextInputType,
        TextStyle,
        Widget,
        heightSpaceBox,
        textLine,
        translate;

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final data = Get.find<LoginController>();
    var passwordVisible = true.obs;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            heightSpaceBox(size: 10),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      "assets/images/logo_task.png",
                      width: SizeConfig.blockSizeHorizontal = 150,
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.all(29.0),
                  child: Column(
                    // mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text(
                            "SIGN IN TO YOUR ACCOUNT",
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: MediaQuery.of(context).size.height * 0.01,
                          ),
                          textLine(
                            title: ' ',
                            color: AppColors.blackShade2,
                            fontSize: 10,
                          ),
                          // SizedBox(width: MediaQuery.of(context).size.width * 0.01,),
                        ],
                      ),
                      SizedBox(
                        height: SizeConfig.blockSizeVertical = 10,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Email',
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: AppColors.textColor),
                          ),
                          heightSpaceBox(size: 5),
                          TextField(
                            controller: data.emailController,
                            // inputFormatters: const <TextInputFormatter>[],
                            // keyboardType: const TextInputType.numberWithOptions(),
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.all(15),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: const BorderSide(
                                  color: AppColors.primaryText,
                                ),
                              ),
                              filled: true,
                              border: const OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.teal),
                              ),
                              focusedBorder: const OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: AppColors.primaryText),
                              ),
                              fillColor: Colors.white,
                              labelText: 'Enter your Email',
                              labelStyle: TextStyle(
                                color: AppColors.primaryText,
                                fontFamily: 'zoho',
                                fontSize: SizeConfig.safeBlockVertical = 12,
                              ),
                              // prefixIcon: Icon(Icons.call_outlined),
                            ),
                          ),
                        ],
                      ),
                      heightSpaceBox(size: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Password',
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: AppColors.textColor),
                          ),
                          heightSpaceBox(size: 5),
                          Obx(() => TextField(
                                controller: data.passwordController,
                                obscureText: passwordVisible.value,
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.all(15),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(
                                      color: AppColors.primaryText,
                                    ),
                                  ),
                                  filled: true,
                                  fillColor: Colors.white,
                                  border: const OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.teal),
                                  ),
                                  labelText: translate('enter_your_password'),
                                  labelStyle: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: 'zoho',
                                    fontSize: SizeConfig.safeBlockVertical = 12,
                                  ),
                                  helperStyle:
                                      const TextStyle(color: Colors.green),
                                  suffixIcon: IconButton(
                                    icon: Obx(() => Icon(passwordVisible.isTrue
                                        ? Icons.visibility
                                        : Icons.visibility_off)),
                                    onPressed: () {
                                      passwordVisible.value =
                                          !passwordVisible.value;
                                    },
                                  ),
                                  alignLabelWithHint: false,
                                ),
                                keyboardType: TextInputType.visiblePassword,
                                textInputAction: TextInputAction.done,
                              ))
                        ],
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          onPressed: () => data.signIn(),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.buttonColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            foregroundColor: Colors.white,
                          ),
                          child: Center(
                            child: textLine(
                              title: "Login",
                              color: AppColors.white,
                              isBold: true,
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                      heightSpaceBox(size: 15),
                      InkWell(
                          onTap: () => Get.toNamed('signup'),
                          child: const Text(
                            'Create New Account',
                            style: TextStyle(
                                color: AppColors.buttonColor, fontSize: 12),
                          ))
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
