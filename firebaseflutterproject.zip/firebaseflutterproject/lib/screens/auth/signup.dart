import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../view_list.dart'
    show
        AppColors,
        BorderRadius,
        BorderSide,
        BuildContext,
        Column,
        EdgeInsets,
        FontWeight,
        Icon,
        Image,
        LoginController,
        MainAxisAlignment,
        Row,
        SingleChildScrollView,
        SizeConfig,
        SizedBox,
        State,
        StatefulWidget,
        Text,
        TextInputAction,
        TextInputType,
        TextStyle,
        Widget,
        buildRoundButton,
        translate;
import '../../widget/textbox.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  @override
  Widget build(BuildContext context) {
    final data = Get.find<LoginController>();
    var passwordVisible = true.obs;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 25),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  "assets/images/logo_task.png",
                  width: SizeConfig.blockSizeHorizontal = 150,
                ),
              ],
            ),
            const Text("Signup",
                style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.w500,
                    color: AppColors.buttonColor)),
            const SizedBox(
              height: 50,
            ),
            CustomTextField(
              hint: "Enter Name",
              label: "Name",
              controller: data.nameController,
            ),
            const SizedBox(height: 20),
            CustomTextField(
              hint: "Enter Email",
              label: "Email",
              controller: data.emailController,
            ),
            const SizedBox(height: 20),
            Obx(() => TextField(
                  controller: data.passwordController,
                  obscureText: passwordVisible.value,
                  decoration: InputDecoration(
                    contentPadding: const EdgeInsets.all(15),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: AppColors.primaryText,
                      ),
                    ),
                    filled: true,
                    fillColor: Colors.white,
                    border: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.teal),
                    ),
                    labelText: translate('enter_your_password'),
                    labelStyle: TextStyle(
                      color: AppColors.primaryText,
                      fontFamily: 'zoho',
                      fontSize: SizeConfig.safeBlockVertical = 12,
                    ),
                    helperStyle: const TextStyle(color: Colors.green),
                    suffixIcon: IconButton(
                      icon: Obx(() => Icon(passwordVisible.isTrue
                          ? Icons.visibility
                          : Icons.visibility_off)),
                      onPressed: () {
                        passwordVisible.value = !passwordVisible.value;
                      },
                    ),
                    alignLabelWithHint: false,
                  ),
                  keyboardType: TextInputType.visiblePassword,
                  textInputAction: TextInputAction.done,
                )),
            const SizedBox(height: 30),
            buildRoundButton(
                width: double.infinity,
                height: 50,
                title: "signup",
                onPressed: () => data.signup()),
            // CustomButton(
            //   label: "Signup",
            //   onPressed: data.signup,
            // ),
            const SizedBox(height: 5),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Text("Already have an account? "),
              InkWell(
                onTap: () => Get.back(),
                child: const Text("Login",
                    style: TextStyle(color: AppColors.buttonColor)),
              )
            ]),
          ],
        ),
      ),
    );
  }
}
