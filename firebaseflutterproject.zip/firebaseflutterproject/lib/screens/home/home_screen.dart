import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../view_list.dart'
    show
        AppColors,
        Axis,
        BorderRadius,
        BoxDecoration,
        BoxFit,
        BuildContext,
        Builder,
        Container,
        Curves,
        CustomScrollView,
        DecorationImage,
        HomeController,
        Icon,
        NetworkImage,
        SizedBox,
        SliverToBoxAdapter,
        StatelessWidget,
        Text,
        TextStyle,
        Widget;
import 'package:shimmer/shimmer.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Get.find<HomeController>().getImage();
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: AppColors.buttonColor,
        title: const Text(
          'tasks',
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          InkWell(
            onTap: () => Get.toNamed('search'),
            child: const Icon(
              Icons.search_rounded,
              color: Colors.white,
            ),
          )
        ],
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: getSlider(),
          )
        ],
      ),
    );
  }
}

Widget getSlider({double width = 1, double radius = 0}) =>
    GetBuilder<HomeController>(
      builder: (controller) => Obx(() {
        if (controller.isLoading.value == false && controller.data.isNotEmpty) {
          return SizedBox(
            width: double.infinity,
            child: CarouselSlider(
              options: CarouselOptions(
                viewportFraction: width,
                initialPage: 0,
                enableInfiniteScroll: true,
                reverse: false,
                autoPlay: true,
                autoPlayInterval: const Duration(seconds: 10),
                autoPlayAnimationDuration: const Duration(milliseconds: 600),
                autoPlayCurve: Curves.fastOutSlowIn,
                enlargeCenterPage: true,
                enlargeFactor: 0.3,
                scrollDirection: Axis.horizontal,
              ),
              items: controller.data.map<Widget>((item) {
                var imageUrl = item['urls']['regular'];
                return Builder(
                  builder: (BuildContext context) => Container(
                    decoration: BoxDecoration(
                      borderRadius:
                          radius == 0 ? BorderRadius.circular(radius) : null,
                      image: DecorationImage(
                        image: NetworkImage(imageUrl),
                        fit: BoxFit
                            .cover, // Add BoxFit to ensure proper image scaling
                      ),
                      color: AppColors.white,
                    ),
                  ),
                );
              }).toList(),
            ),
          );
        } else {
          return getSliderSkl(); // Show skeleton loader when data is loading
        }
      }),
    );

Widget getSliderSkl() => Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: CarouselSlider(
        options: CarouselOptions(
          height: Get.height * 0.3,
          viewportFraction: 1,
          initialPage: 0,
          enableInfiniteScroll: true,
          reverse: false,
          autoPlay: true,
          autoPlayInterval: const Duration(seconds: 10),
          autoPlayAnimationDuration: const Duration(milliseconds: 300),
          autoPlayCurve: Curves.fastOutSlowIn,
          enlargeCenterPage: true,
          enlargeFactor: 0.3,
          scrollDirection: Axis.horizontal,
        ),
        items: List.generate(
          3,
          (index) => Builder(
            builder: (BuildContext context) => Container(
              decoration: const BoxDecoration(
                color: Colors.grey,
              ),
            ),
          ),
        ),
      ),
    );
