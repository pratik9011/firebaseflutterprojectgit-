import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../view_list.dart'
    show
        AppColors,
        AssetImage,
        BorderRadius,
        BoxDecoration,
        BuildContext,
        Center,
        Column,
        Container,
        EdgeInsets,
        Icon,
        Image,
        LoginController,
        Radius,
        SingleChildScrollView,
        SizeConfig,
        SizedBox,
        StatelessWidget,
        Text,
        VoidCallback,
        Widget,
        showDialogYesNoWithImage,
        textLine;

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        title: const Text('Profile'),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: [
              Center(
                child: Column(
                  children: [
                    const CircleAvatar(
                        radius: 60,
                        foregroundColor: AppColors.white,
                        backgroundImage: AssetImage('assets/images/es2.png')),
                    SizedBox(height: SizeConfig.blockSizeVertical = 10),
                    const Text("pratik patil")
                  ],
                ),
              ),
              SizedBox(height: SizeConfig.blockSizeVertical = 10),
              _buildCard(
                onTap: () => Get.toNamed(''),
                leadingAsset: "assets/images/edit_Profile.png",
                title: "Edit Profile",
              ),
              SizedBox(height: SizeConfig.blockSizeVertical = 2),
              _buildCard(
                onTap: () {},
                leadingAsset: 'assets/images/Help_&_support.png',
                title: "Help & support",
              ),
              SizedBox(height: SizeConfig.blockSizeVertical = 2),
              _buildCard(
                onTap: () {},
                leadingAsset: "assets/images/Account_delete.png",
                title: "Delete Account",
              ),
              SizedBox(height: SizeConfig.blockSizeVertical = 2),
              _buildCard(
                onTap: () {
                  showDialogYesNoWithImage(
                      title: "logout",
                      content: "are_you_sure_to_logout",
                      image: "assets/images/logout.png",
                      onPressed: () async {
                        final SharedPreferences prefs =
                            await SharedPreferences.getInstance();
                        prefs.clear();
                        Get.find<LoginController>().signOut();
                        Get.offAllNamed("login");
                      },
                      btnTitle: "logout");
                },
                leadingAsset: "assets/images/logout.png",
                title: "Logout",
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCard({
    required VoidCallback onTap,
    required String leadingAsset,
    required String title,
  }) {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(16)),
      ),
      child: Card(
        color: Colors.white,
        child: ListTile(
          onTap: onTap,
          leading: Image.asset(leadingAsset),
          title: textLine(
            title: title,
            fontSize: 14,
            isBold: true,
            color: AppColors.blackShade4,
          ),
          trailing: Container(
            decoration: const BoxDecoration(
              color: AppColors.buttonColor,
              borderRadius: BorderRadius.all(Radius.circular(8)),
            ),
            child: IconButton(
              onPressed: onTap,
              icon: const Icon(
                Icons.arrow_forward_ios,
                color: AppColors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
