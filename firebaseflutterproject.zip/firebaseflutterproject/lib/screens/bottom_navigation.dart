import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'view_list.dart';

class BottomNavBar extends StatelessWidget {
  const BottomNavBar({super.key});

  @override
  Widget build(BuildContext context) {
    final data = Get.find<BottomNavigationController>();

    return Obx(() => Scaffold(
          backgroundColor: AppColors.white,
          body: Center(
            child: BottomNavigationController.widgetOptions
                .elementAt(data.selectedIndex.value),
          ),
          bottomNavigationBar: BottomNavigationBar(
            unselectedItemColor: Colors.grey,
            backgroundColor: AppColors.white,
            showSelectedLabels: true,
            items: <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                backgroundColor: Colors.white,
                icon: Icon(
                  Icons.home,
                  size: SizeConfig.safeBlockVertical = 30,
                ),
                label: translate('home'),
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.white,
                icon: Icon(
                  Icons.search,
                  size: SizeConfig.safeBlockVertical = 30,
                ),
                label: translate('search'),
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.white,
                icon: Icon(
                  Icons.person,
                  size: SizeConfig.safeBlockVertical = 30,
                ),
                label: translate('profile'),
              ),
            ],
            currentIndex: data.selectedIndex.value,
            selectedItemColor: AppColors.buttonColor,
            onTap: (index) {
              data.updateIndex(index);
            },
          ),
        ));
  }
}
