import 'package:flutter/material.dart';

class LanguageHelper {
  convertLangNameToLocale(String langNameToConvert) {
    Locale convertedLocale;

    switch (langNameToConvert) {
      case "english":
        convertedLocale = const Locale('en', 'EN');
        break;
      case "french":
        convertedLocale = const Locale('fr', 'FR');
        break;
      case 'spanish':
        convertedLocale = const Locale('es', 'ES');
        break;
      case 'arabic':
        convertedLocale = const Locale('ar', 'AE');
        break;
      default:
        convertedLocale = const Locale('en', 'EN');
    }

    return convertedLocale;
  }

  convertLocaleToLangName(String localeToConvert) {
    String langName;

    switch (localeToConvert) {
      case 'en':
        langName = "English";
        break;
      case 'fr':
        langName = "Français";
        break;
      case 'es':
        langName = "Español";
        break;
      case 'ru':
        langName = "Русский";
        break;
      default:
        langName = "English";
    }

    return langName;
  }
}