import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../components/components_list.dart' show WidgetsBinding;

class HomeController extends GetxController {
  String appUrl = '';
  var isLoading = true.obs;
  var show = true.obs;
  var data;
  RxString imageUrl = ''.obs;

  @override
  void onInit() async {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      getImage();
    });
    super.onInit();
  }

  void getImage() async {
    try {
      isLoading.value = true;
      final url = Uri.parse(
          'https://api.unsplash.com/photos/?client_id=ZRRXF7BzifkRRveiYSly1bulB1VzA7XCjQSvRaZtnz0');

      final response = await http.get(url);

      if (response.statusCode == 200) {
        data = json.decode(response.body) as List<dynamic>;

        if (data.isNotEmpty) {
          if (kDebugMode) {
            print(data[1]);
          }

          var imageData = data[0]; // Example: grabbing the second image
          imageUrl.value = imageData['urls']['regular'];
          if (kDebugMode) {
            print(imageUrl.value);
          }
        } else {
          if (kDebugMode) {
            print('No images available');
          }
        }
      } else {
        if (kDebugMode) {
          print('Failed to load images: ${response.statusCode}');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error occurred: $e');
      }
    } finally {
      isLoading.value =
          false;
    }
  }

  void searchImage({required String searchKeyword}) async {
    try {
      isLoading.value = true;
      final url = Uri.parse(
          'https://api.unsplash.com/search/photos?client_id=ZRRXF7BzifkRRveiYSly1bulB1VzA7XCjQSvRaZtnz0&query=$searchKeyword');
      final response = await http.get(url);
      if (kDebugMode) {
        print(response.body);
      }

      if (response.statusCode == 200) {
        final data2 = json.decode(response.body) as Map<String, dynamic>;

        if (data2['results'] != null && data2['results'].isNotEmpty) {
          if (kDebugMode) {
            print('Images found');
          }
          var imageData = data2['results'][0];
          data = data2[0];
          imageUrl.value =
              imageData['urls']['full']; // Get the regular-sized image URL
          if (kDebugMode) {
            print(imageUrl.value);
          }
          show.value = false; // Hide loading indicator
        } else {
          if (kDebugMode) {
            print('No images available');
          }
        }
      } else {
        if (kDebugMode) {
          print('Failed to load images: ${response.statusCode}');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error occurred: $e');
      }
    } finally {
      isLoading.value =
          false; // Set isLoading to false after request completion
    }
  }
}
