import 'controller_list.dart' show HomeScreen, ProfileScreen, Widget;
import '../screens/search/search_screen.dart';
import 'package:get/get.dart' show GetxController, IntExtension;

class BottomNavigationController extends GetxController {
  var selectedIndex = 0.obs;

  static final List<Widget> widgetOptions = <Widget>[
    const HomeScreen(),
    const SearchScreen(),
    const ProfileScreen(),
  ];

  void updateIndex(int index) {
    selectedIndex.value = index;
  }
}
