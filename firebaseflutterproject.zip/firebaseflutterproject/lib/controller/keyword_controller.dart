import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class KeywordController extends GetxController {
  RxBool isLoading = false.obs;
  RxList<Map<String, dynamic>> keywords = <Map<String, dynamic>>[].obs;

  final CollectionReference keywordCollection =
      FirebaseFirestore.instance.collection('tbl_search_history');

  Future<void> fetchKeywords() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();

      String? emailId = prefs.getString('auth_Key');

      if (emailId == null) {
        if (kDebugMode) {
          print("No emailId found in SharedPreferences.");
        }
        return;
      }

      isLoading(true);
      QuerySnapshot querySnapshot = await keywordCollection
          .where('email_id', isEqualTo: emailId) // Filter by email_id
          .get();

      List<QueryDocumentSnapshot> documents = querySnapshot.docs;

      keywords.value = documents
          .map((doc) => {
                'id': doc.id,
                'keyword': doc['keyword'],
                'email_id': doc['email_id'],
                'created_by': doc['created_by'],
              })
          .toList();
    } catch (e) {
      if (kDebugMode) {
        print("Error fetching data: $e");
      }
    } finally {
      isLoading(false);
    }
  }

  // Method to add data to Firestore
  Future<void> addKeyword(String keyword, String ct) async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      String? emailId = prefs.getString('auth_Key');
      isLoading(true);
      await keywordCollection.add({
        'keyword': keyword,
        'email_id': emailId,
        'created_by': ct,
      });
      await fetchKeywords();
    } catch (e) {
      if (kDebugMode) {
        print("Error adding data: $e");
      }
    } finally {
      isLoading(false);
    }
  }

  Future<void> deleteKeyword(String documentId) async {
    try {
      isLoading(true);
      await keywordCollection.doc(documentId).delete();
      await fetchKeywords();
    } on FirebaseException catch (e) {
      if (kDebugMode) {
        print("Firebase Error: ${e.message}");
        print("Code: ${e.code}");
        print("Details: $e");
      }
    } catch (e) {
      if (kDebugMode) {
        print("Unknown Error: $e");
      }
    } finally {
      isLoading(false); // Set loading to false after deleting data
    }
  }
}
