import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../components/components_list.dart';

import 'package:get/get.dart'
    show BoolExtension, Get, GetNavigation, GetxController;

class LoginController extends GetxController {
  var isLoading = true.obs;
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final nameController = TextEditingController();
  final auth = FirebaseAuth.instance;

  void signIn() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      var result = await auth.signInWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );
      await prefs.setString('auth_Key', result.user!.email.toString());
      String? token = prefs.getString('auth_Key');
      print(token);
      showStatusPopup(
          title: "login",
          content: "login_successfully",
          isSuccess: true,
          onPressed: () => Get.offAllNamed('mainPage'));
    } on FirebaseAuthException catch (e) {
      showStatusPopup(
          title: "invalid_enter",
          content: "please_check_username_&_password!!!",
          isSuccess: false,
          onPressed: () => Get.back());
    }
  }

  void signOut() async {
    await auth.signOut();
  }

  signup() async {
    final user = await auth.createUserWithEmailAndPassword(
        email: emailController.text, password: passwordController.text);
    if (user.additionalUserInfo!.isNewUser == true) {
      showStatusPopup(
          title: "signup",
          content: "new_account_created_successfully",
          isSuccess: true,
          onPressed: () => Get.toNamed('login'));
    } else {
      showStatusPopup(
          title: "invalid_enter",
          content: "please_check_username_&_password!!!",
          isSuccess: false,
          onPressed: () => Get.back());
    }
  }
}
